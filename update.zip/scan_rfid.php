<?php
include "config.php";

if (isset($_GET['rfid_uid'])) {
    $uid = $conn->real_escape_string($_GET['rfid_uid']);

    // Cari UID di tabel user
    $q = $conn->query("SELECT * FROM users WHERE rfid_uid='$uid'");
    if ($q->num_rows > 0) {
        $user = $q->fetch_assoc();
        $userId = $user['id'];

        // Cek apakah hari ini sudah ada absensi masuk
        $today = date("Y-m-d");
        $cek = $conn->query("SELECT * FROM absensi WHERE user_id='$userId' AND DATE(waktu)='$today'");

        if ($cek->num_rows == 0) {
            // Belum ada -> catat Hadir
            $conn->query("INSERT INTO absensi (user_id, status) VALUES ('$userId','Hadir')");
            echo "<div class='alert alert-success'>✅ Selamat datang, {$user['nama']}! Absensi masuk tercatat.</div>";
        } else {
            // Sudah ada -> catat Pulang
            $conn->query("INSERT INTO absensi (user_id, status) VALUES ('$userId','Pulang')");
            echo "<div class='alert alert-warning'>👋 Sampai jumpa, {$user['nama']}! Pulang tercatat.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>❌ UID tidak dikenal!</div>";
    }
} else {
    echo "<div class='alert alert-danger'>❌ UID kosong!</div>";
}
?>
