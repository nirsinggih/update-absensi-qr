<?php
$host = "localhost";
$user = "fyxhpdmx_absensiv4";
$pass = "fyxhpdmx_absensiv4";
$db = "fyxhpdmx_absensiv4";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
