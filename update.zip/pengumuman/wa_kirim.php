<?php
session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include "config.php";
date_default_timezone_set("Asia/Jakarta");

// === Ambil Token WA Sidobe dari profil_sekolah id=1 ===
$q = mysqli_query($conn, "SELECT key_wa_sidobe FROM profil_sekolah WHERE id=1");

if (!$q) {
    die("<h3 style='color:red;'>❌ Query gagal:</h3><pre>" . mysqli_error($conn) . "</pre>");
}

$row = mysqli_fetch_assoc($q);
if (!$row || empty($row['key_wa_sidobe'])) {
    die("<h3 style='color:red;'>⚠️ Token WA Sidobe belum diset di tabel profil_sekolah (id=1).</h3>");
}
$token = $row['key_wa_sidobe'];

// === Proses Kirim WA ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pesan'])) {
    $pesan = $_POST['pesan'];

    // Ambil data siswa: nama, kelas, dan nomor WA ortu
    $siswaQ = mysqli_query($conn, "SELECT nama, kelas, no_wa FROM siswa WHERE no_wa <> ''");

    if (!$siswaQ) {
        die("<h3 style='color:red;'>❌ Query siswa gagal:</h3><pre>" . mysqli_error($conn) . "</pre>");
    }

    $count = 0;
    while ($s = mysqli_fetch_assoc($siswaQ)) {
        $count++;

        // Format pesan (bisa pakai placeholder)
        $pesanFinal = str_replace(
            ["{nama}", "{kelas}"],
            [$s['nama'], $s['kelas']],
            $pesan
        );

        $nomor = $s['no_wa_ortu'];

        // Kirim ke API Sidobe
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.sidobe.com/send-message",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                "Authorization: Bearer $token",
                "Content-Type: application/json"
            ],
            CURLOPT_POSTFIELDS => json_encode([
                "number" => $nomor,
                "message" => $pesanFinal
            ])
        ]);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            echo "❌ Error kirim ke {$s['nama']} ($nomor): $err<br>";
        } else {
            echo "✅ Pesan terkirim ke {$s['nama']} ($nomor)<br>";
        }

        // Jeda acak 2–5 detik
        $delay = rand(2, 5);
        sleep($delay);
    }

    echo "<hr><b>Selesai! Total pesan terkirim: $count</b>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Kirim WA Massal</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-4">
  <h2>📢 Kirim WA Massal ke Orang Tua Siswa</h2>
  <a href="dashboard.php" class="btn btn-secondary mb-3">← Kembali</a>

  <form method="POST">
    <div class="mb-3">
      <label for="pesan" class="form-label">Format Pesan</label>
      <textarea name="pesan" id="pesan" rows="5" class="form-control" placeholder="Contoh: Yth. {nama} dari kelas {kelas}, besok masuk pukul 07.00 WIB." required></textarea>
      <div class="form-text">Gunakan <b>{nama}</b> dan <b>{kelas}</b> untuk otomatis diganti.</div>
    </div>
    <button type="submit" class="btn btn-primary">🚀 Kirim Pesan Massal</button>
  </form>
</body>
</html>
