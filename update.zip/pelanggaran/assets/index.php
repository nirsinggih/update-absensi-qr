<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

// Jika role guru, arahkan ke dashboard guru
if ($_SESSION['role'] === 'guru') {
    header("Location: dashboard_guru.php");
    exit;
}

// Jika bukan admin (misalnya siswa, dll.) kembalikan ke index
if ($_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Pelanggaran</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container">
    <h2>📋 Kredit Poin Pelanggaran</h2>

    <div class="card">
        <a href="tambah.php"><button>➕ Tambah Pelanggaran</button></a>
    </div>

    <div class="card">
        <a href="riwayat.php"><button>📖 Riwayat Pelanggaran</button></a>
    </div>
</div>
</body>
</html>
